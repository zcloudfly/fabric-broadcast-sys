<template>
  <div id="app">
    <router-view />
  </div>

</template>

<script>

</script>

<style>
@import './assets/css/index.css';
</style>
