<template>
    <div class="index2">
        <h1>index2</h1>

    </div>
</template>