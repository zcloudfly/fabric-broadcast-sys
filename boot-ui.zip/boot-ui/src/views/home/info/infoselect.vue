<template>
  <div class="about">
    <h1>信息查询</h1>
  </div>
</template>