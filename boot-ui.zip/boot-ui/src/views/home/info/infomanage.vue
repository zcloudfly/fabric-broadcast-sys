<template>
  <div>

     <router-view />
  </div>
</template>

<script>

export default {
  data () {
    return {

    }
  },
  components:{
  },
  mounted(){

  },
  methods: {

  }
}
</script>

<style scoped>

</style>
